# Files
- Short_notebook_1.ipynb: Random Forest implementation with 115.8 on Kaggle.
- Short_notebook_2.ipynb: Darts with LightGBM with 159.1 on Kaggle.
- requirements.txt: all dependencies we require
- Report.pdf: Our report

# Python-version

Use python=3.10

# Running the notebooks

The notebooks assumes that the data is located in the same folder.

Run `pip install -r requirements.txt` to install dependencies.

# Submission files

Submission files are called: submission.csv

